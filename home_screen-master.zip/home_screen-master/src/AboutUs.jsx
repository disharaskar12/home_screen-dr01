import React from "react";
import bkg from "../src/images/newbg.PNG";

const AboutUs = () => {
  const boldTextStyle = { fontWeight: "bold" };

  return (
    <section
      id="about-us"
      className="section mt-0 mb-0"
      style={{
        backgroundColor:"#d9712b",
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
        backgroundPosition: "center center",
        padding: "20px",
        borderRadius: "15px",
      }}
    >
      <div className="container">
        <div className="row">
          <div className="col">
            <h2 className="text-light" style={boldTextStyle}>
              <strong>About Us</strong>
            </h2>
            <h5>
              <p className="text-black" style={boldTextStyle}>
                <strong>Professional Trainers</strong>
                <br />
                We have a team of best corporate trainers with 9-10 years of
                experience in the IT industry.
                <br />
                <br />
                <strong>Flexible Time</strong>
                <br />
                Training period time is flexible as per your requirement and
                schedule.
                <br />
                <br />
                <strong>Real-Time Projects</strong>
                <br />
                After training, we guide you to develop a full-fledged project
                by assigning real-time projects.
              </p>
            </h5>
          </div>
          <div className="col">
            <h2 className="text-light" style={boldTextStyle}>
              <strong>Contact Us</strong>
            </h2>
            <h5>
              <p className="text-black" style={boldTextStyle}>
                <strong>InfobytesTechnosys.in</strong>
                <br />
                <br />
                MailId: <strong>reachus@infobytestechnosys.in</strong>
              </p>
            </h5>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
