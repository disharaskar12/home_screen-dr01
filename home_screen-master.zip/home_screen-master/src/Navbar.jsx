import React from "react";
import { NavLink } from "react-router-dom";
import { Image } from "react-bootstrap";
import backgroundImg from "../src/images/navbg.jpg";

const Navbar = () => {
  const orangeTextStyle = { color: "#ee7809" };
  const boldUnderlineStyle = {
    borderBottom: "3px solid #000000",
    paddingBottom: "5px",
  };
  const boldTextStyle = { fontWeight: "bold" };
  const backgroundStyle = {
    backgroundImage: `url(${backgroundImg})`,
    backgroundSize: "cover",
  };

  return (
    <div>
      <div className="container-fluid p-0">
        <nav
          className="navbar navbar-expand-lg navbar-warning"
          style={{
            ...backgroundStyle,
            backgroundColor: "rgba(248, 249, 250, 0.8)",
          }}
        >
          <div className="container d-flex justify-content-between align-items-center">
            <NavLink className="navbar-brand pt-0 pb-0" to="/">
              <Image
                className="i1 ms-0 ps-0"
                src={require("./images/newlogomain2.png")}
                height={150}
                width={230}
                alt="Logo"
              />
            </NavLink>
            <div className="text-center">
              <h5
                className="t1 mb-1"
                style={{
                  ...boldTextStyle,
                  ...orangeTextStyle,
                  ...boldUnderlineStyle,
                }}
              >
                INFOBYTES TECHNOSYS
              </h5>
              <h6 className="t2 mb-0" style={orangeTextStyle}>
                we believe in transparency
              </h6>
            </div>

            <div className="text-end">
              <ul className="navbar-nav mb-2 mb-lg-0">
                <li className="nav-item" style={orangeTextStyle}>
                  <NavLink
                    exact
                    activeClassName="active"
                    className="nav-link"
                    to="/"
                    style={{ color: "#343A40" }}
                  >
                    <strong>Home</strong>
                  </NavLink>
                </li>
                <li className="nav-item" style={orangeTextStyle}>
                  <NavLink
                    activeClassName="active"
                    className="nav-link"
                    to="/company"
                    style={{ color: "#343A40" }}
                  >
                    <strong>Company</strong>
                  </NavLink>
                </li>
                <li className="nav-item" style={orangeTextStyle}>
                  <NavLink
                    activeClassName="active"
                    className="nav-link"
                    to="/aboutus"
                    style={{ color: "#343A40" }}
                  >
                    <strong>About Us</strong>
                  </NavLink>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
};

export default Navbar;
