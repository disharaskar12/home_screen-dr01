import React from "react";
import bkg from "../src/images/newbg.PNG";
import gif from "../src/images/payTrakz_gif.mp4";
import image1 from "../src/images/product_1.jpg";
import image2 from "../src/images/product_1.jpg";
import image3 from "../src/images/product_3.jpg";
import image4 from "../src/images/product_1.jpg";
import pic from "../src/images/DE.png";
import addimg from "../src/images/newlog.png";
import tech from "../src/images/joinus.jpg";

const Home = () => {
  const boldTextStyle = { fontWeight: "bold" };

  return (
    <section
      id="header"
      className="section mt-0 mb-0"
      style={{
        backgroundColor:"#d9712b",
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
        backgroundPosition: "center center",
        padding: "20px",
        borderRadius: "15px",
      }}
    >
      <div className="container">
        <div className="row row-cols-1 g-4">
          <div className="col">
            <div className="card mb-3 bg-transparent border-0">
              <div className="card-body text-dark">
                <h2
                  className="card-title text-center mb-4"
                  style={boldTextStyle}
                >
                  <strong>
                    Make everyday life more affordable and protected for
                    Customers.
                  </strong>
                </h2>
                <p>
                  <span>
                    <h5 className="card-text text-center" style={boldTextStyle}>
                      <a
                        href="/"
                        className="text-decoration-none hover-underline"
                      >
                        <strong className="brand-name text-light">
                          Infobytes Technosys
                        </strong>
                      </a>{" "}
                      is a solution company that increases the value of
                      customer/client relationships.
                    </h5>
                  </span>
                </p>
              </div>
            </div>
          </div>

          <div className="col">
            <div className="card mb-2 bg-transparent border-lg-5">
              <div className="card-body text-black">
                <h3 className="card-title text-center" style={boldTextStyle}>
                  <strong className="head2 text-bold text-light ">
                    Our Products
                  </strong>
                </h3>
                <p className="card-text ms-md-5">
                  <h4>
                    <strong className="paytrak text-danger text-decoration-underline-bg-primary">
                      PayTrakz
                    </strong>
                  </h4>
                  <h5 style={boldTextStyle}>The most powerful Partnership</h5>
                </p>
                <div className="d-flex justify-content-center mb-5 mt-3">
                  <img
                    src={addimg}
                    className="img-fluid me-3 shadow"
                    alt="AdditionalImage"
                    style={{ Width: "600px", maxHeight: "300px" }}
                  />
                  <video
                    className="gif me-4 shadow"
                    src={gif}
                    autoPlay
                    loop
                    muted
                    playsInline
                    alt="paytrakzgif"
                    style={{ maxWidth: "600px", maxHeight: "300px" }}
                  />
                </div>
                <div className="d-flex justify-content-center ms-md-5 me-0">
                  <img
                    src={image1}
                    className="img-fluid me-md-5"
                    alt="Product1"
                    style={{ width: "22%", height: "30%" }}
                  />
                  <img
                    src={image2}
                    className="img-fluid me-md-5"
                    alt="Product2"
                    style={{ width: "22%", height: "30%" }}
                  />
                  <img
                    src={image3}
                    className="img-fluid me-md-5"
                    alt="Product3"
                    style={{ width: "22%", height: "30%" }}
                  />
                  <img
                    src={image4}
                    className="img-fluid me-md-5"
                    alt="Product4"
                    style={{ width: "22%", height: "30%" }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="col">
            <div className="card mb-3 bg-transparent border-lg-5 ">
              <div className="row g-0">
                <div className="col-md-8">
                  <div className="card-body text-black">
                    <h3
                      className="card-title text-center text-light"
                      style={boldTextStyle}
                    >
                      <strong>Key Offerings</strong>
                    </h3>
                    <h5>
                      <p className="card-text" style={boldTextStyle}>
                        Delivering new experiences with reliable engineering.
                        <ul style={boldTextStyle}>
                          <li>
                            <strong>Digital Product Engineering:</strong>{" "}
                            Infobytes Technosys offers a host of highly flexible
                            and adaptable solutions and services for businesses,
                            from building new products to modernizing existing
                            ones. High-value agile solutions that are built to
                            match your speed of innovation.
                          </li>
                          <li>
                            <strong>Talent Solutions:</strong> Optimize your
                            organization’s workforce with reliable and skilled
                            individuals via technology-driven, flexible talent
                            solutions from Infobytes Technosys.
                          </li>
                        </ul>
                      </p>
                    </h5>
                  </div>
                </div>
                <div className="col-md-4 d-flex justify-content-md-end justify-content-center">
                  <img
                    src={pic}
                    className="img-fluid me-md-3 border-0 shadow"
                    alt="paytrakz"
                    style={{ width: "100%", height: "auto" }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="col">
            <div className="card bg-transparent border-lg-5">
              <div className="card-body text-black d-flex flex-column align-items-center">
                <h3
                  className="card-title text-center text-light mb-3"
                  style={boldTextStyle}
                >
                  <strong>Join Infobytes Tech world</strong>
                </h3>
                <h5>
                  <p
                    className="card-text text-center mb-3"
                    style={boldTextStyle}
                  >
                    If you're passionate about technology and finance, Infobytes
                    Technosys is the place to be. Explore exciting career
                    opportunities and be part of our pioneering journey. Join us
                    in shaping the future of fintech!
                  </p>
                </h5>
                <div className="d-flex gap-5">
                  <a
                    href="https://docs.google.com/forms/d/e/1FAIpQLScHM22QHO8Id5CRZ3qTPcKB1fRV70I-zjE3niY77gojaBV8FA/viewform?usp=sf_link"
                    className="text-decoration-none"
                  >
                    <button
                      type="button"
                      className="btn btn-primary btn-lg"
                      style={boldTextStyle}
                    >
                      Apply for Fresher
                    </button>
                  </a>
                  <a
                    href="https://docs.google.com/forms/d/e/1FAIpQLSeH7Wacpq1F3zhgYmVzKanVRlUZZUUQht-oqdg0uBNB7Tzg2w/viewform?usp=sf_link"
                    className="text-decoration-none"
                  >
                    <button
                      type="button"
                      className="btn btn-primary btn-lg"
                      style={boldTextStyle}
                    >
                      Apply for Experience
                    </button>
                  </a>
                  <a
                    href="https://docs.google.com/forms/d/e/1FAIpQLScN4IG-G0d0XJvZPAz4z4pIKEKvWUtw1kB56K1ESMK4yq-rxg/viewform?usp=sf_link"
                    className="text-decoration-none"
                  >
                    <button
                      type="button"
                      className="btn btn-primary btn-lg"
                      style={boldTextStyle}
                    >
                      Training cum Internship Program
                    </button>
                  </a>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Home;
